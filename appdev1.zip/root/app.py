import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_restful import Resource, Api
from sqlalchemy.orm import relationship


app = Flask(__name__)
app.secret_key = 'SK234J8sd48)@z@!0nnFDNlkjsoinc#ghp*$()'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['UPLOAD_FOLDER'] = '/Users/himaruthshriram/Documents/3rd sem/Appdev 1 project/songs'
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
bcrypt = Bcrypt(app)
api = Api(app)

class User(db.Model, UserMixin):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(25), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)  # Increased the length for hashed passwords
    is_admin = db.Column(db.Boolean, default=False)
    is_creator = db.Column(db.Boolean, default=False)



# Create a User model
class Album(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    artist = db.Column(db.String(100), nullable=False)
    release_year = db.Column(db.Integer)
    album_art = db.Column(db.String(255))  # Add a field to store the album art filename
    songs = relationship('Song', back_populates='album')


from sqlalchemy.orm import relationship

class Playlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200))

    # Define a relationship with the Song model
    songs = relationship('Song', secondary='playlist_song', back_populates='playlists')

# Define an association table for the many-to-many relationship
playlist_song_association = db.Table('playlist_song',
    db.Column('playlist_id', db.Integer, db.ForeignKey('playlist.id')),
    db.Column('song_id', db.Integer, db.ForeignKey('song.id'))
)


# Create a Rating model
class Rating(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    song_id = db.Column(db.Integer, db.ForeignKey('song.id'), nullable=False)

# Update the Song model to include a relationship with Rating
class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    artist = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.Integer, nullable=False)
    file_path = db.Column(db.String(255))
    lyrics = db.Column(db.Text)

    # Define a relationship with the Playlist model
    playlists = relationship('Playlist', secondary='playlist_song', back_populates='songs')

    # Define a relationship with the Rating model
    ratings = db.relationship('Rating', backref='song', lazy=True)
    album_id = db.Column(db.Integer, db.ForeignKey('album.id'))
    album = relationship('Album', back_populates='songs')

    # Add a method to calculate the average rating
    def calculate_average_rating(self):
        if not self.ratings:
            return None

        total_ratings = sum(rating.rating for rating in self.ratings)
        average_rating = total_ratings / len(self.ratings)
        return average_rating

# Define the SongRating model
class SongRating(db.Model):
    __tablename__ = 'song_rating'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    song_id = db.Column(db.Integer, db.ForeignKey('song.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)

    # Define relationships
    user = db.relationship('User', back_populates='ratings')
    song = db.relationship('Song', back_populates='ratings')

# Add a ratings relationship to the User model
    User.ratings = db.relationship('SongRating', back_populates='user')

# Add a ratings relationship to the Song model
    Song.ratings = db.relationship('SongRating', back_populates='song')



# ... (existing code)

# Route for rating a song
@app.route('/rate_song/<int:song_id>', methods=['POST'])
@login_required
def rate_song(song_id):
    song = Song.query.get_or_404(song_id)

    if request.method == 'POST':
        # Get the user's rating input
        user_rating = int(request.form['rating'])

        # Add the user's rating to the database
        user_rating_entry = SongRating(user_id=current_user.id, song_id=song.id, rating=user_rating)
        db.session.add(user_rating_entry)
        db.session.commit()

        flash('Rating submitted successfully.', 'success')

    # Calculate and update the average rating for the song
    song.average_rating = calculate_average_rating(song.id)
    db.session.commit()

    return redirect(url_for('songs'))

# Function to calculate the average rating for a song
def calculate_average_rating(song_id):
    ratings = SongRating.query.filter_by(song_id=song_id).all()

    # Calculate the average rating
    if ratings:
        total_rating = sum(rating.rating for rating in ratings)
        average_rating = total_rating / len(ratings)
        return round(average_rating, 2)
    else:
        return 0.0

@app.route('/view_album_songs/<int:album_id>')
def view_album_songs(album_id):
    # Fetch the album and its songs from the database
    album = Album.query.get(album_id)
    if album:
        songs = album.songs
        return render_template('view_album_songs.html', album=album, songs=songs)
    else:
        flash('Album not found', 'danger')
        return redirect(url_for('your_albums'))

# Import necessary libraries and models

# ... (existing code)

# Import additional libraries for calculating average rating
from sqlalchemy import func

# Route for the admin dashboard
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.is_admin:
        # Display users, songs, albums, and playlists
        users = User.query.all()
        songs = Song.query.all()
        albums = Album.query.all()
        playlists = Playlist.query.all()

        # Calculate total songs
        total_songs = Song.query.count()

        # Calculate average rating
        average_rating = db.session.query(func.avg(SongRating.rating)).scalar()

        return render_template('admin_dashboard.html', users=users, songs=songs, albums=albums, playlists=playlists, total_songs=total_songs, average_rating=average_rating)
    else:
        flash('Access denied. Only administrators can view the admin dashboard.', 'danger')
        return redirect(url_for('home'))


# Route for deleting a user
@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if current_user.is_admin:
        user = User.query.get_or_404(user_id)

        # Only allow deleting non-admin users
        if not user.is_admin:
            db.session.delete(user)
            db.session.commit()
            flash('User deleted successfully.', 'success')
        else:
            flash('Cannot delete an admin user.', 'danger')

        return redirect(url_for('admin_dashboard'))
    else:
        flash('Access denied. Only administrators can delete users.', 'danger')
        return redirect(url_for('home'))


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        is_admin = bool(request.form.get('is_admin'))  # Check if the admin checkbox is selected
        is_creator = bool(request.form.get('is_creator'))  # Check if the creator checkbox is selected

        # Validate that both password fields match
        if password != confirm_password:
            flash('Passwords do not match. Please enter matching passwords.', 'danger')
            return redirect(url_for('register'))

        if not username or not password:
            flash('Both username and password are required.', 'danger')
            return redirect(url_for('register'))

        # Check if the username is already taken
        if get_user(username):
            flash('Username already taken. Please choose a different one.', 'danger')
            return redirect(url_for('register'))

        create_user(username, password, is_admin,is_creator)
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

def create_user(username, password, is_admin=False,is_creator=False):
    #hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    hashed_password = password
    new_user = User(username=username, password=hashed_password, is_admin=is_admin,is_creator=is_creator)
    db.session.add(new_user)
    db.session.commit()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def get_user(username):
    return User.query.filter_by(username=username).first()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = get_user(username)
        #bcrypt.check_password_hash(user.password, password)
        if user and (user.password == password):
            login_user(user)
            flash('Login successful.', 'success')
            return redirect(url_for('dashboard'))

        flash('Invalid credentials. Please check your username and password and try again.', 'danger')

    return render_template('login.html')

@app.route('/add_song', methods=['GET', 'POST'])
def add_song():
    if request.method == 'POST':
        title = request.form['title']
        artist = request.form['artist']
        duration = request.form['duration']
        lyrics=request.form['lyrics']

        if 'file' in request.files:
            mp3_file = request.files['file']
            if mp3_file.filename != '' and mp3_file.filename.endswith('.mp3'):
                filename = secure_filename(mp3_file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                mp3_file.save(file_path)
            else:
                flash('Please upload an MP3 file.', 'danger')
                return redirect(url_for('add_song'))
        else:
            flash('No file part in the request.', 'danger')
            return redirect(url_for('add_song'))

        new_song = Song(title=title, artist=artist, duration=duration, file_path=file_path,lyrics=lyrics)
        db.session.add(new_song)
        db.session.commit()

        flash('Song added successfully.', 'success')
        return redirect(url_for('songs'))

    return render_template('add_song.html')

@app.route('/edit_song/<int:song_id>', methods=['GET', 'POST'])
def edit_song(song_id):
    song = Song.query.get_or_404(song_id)

    if request.method == 'POST':
        # Update the song details
        song.title = request.form['title']
        song.artist = request.form['artist']
        song.duration = request.form['duration']
        song.lyrics = request.form['lyrics']  # Add this line to update the lyrics

        db.session.commit()

        flash('Song updated successfully.', 'success')
        return redirect(url_for('songs'))

    return render_template('edit_song.html', song=song)


from flask import render_template, abort

@app.route('/view_lyrics/<int:song_id>')
def view_lyrics(song_id):
    song = Song.query.get_or_404(song_id)

    # Check if the song has lyrics
    if not song.lyrics:
        abort(404)  # Return a 404 error if no lyrics are found

    return render_template('view_lyrics.html', song=song)


# Route for deleting a song
@app.route('/delete_song/<int:song_id>', methods=['POST'])
def delete_song(song_id):
    song = Song.query.get_or_404(song_id)
    db.session.delete(song)
    db.session.commit()

    flash('Song deleted successfully.', 'success')
    return redirect(url_for('songs'))


# Error handling
class SongAPI(Resource):
    def get(self):
        try:
            songs = Song.query.all()
            song_list = [{'title': song.title, 'artist': song.artist, 'duration': song.duration} for song in songs]
            return jsonify({'songs': song_list})
        except Exception as e:
            return {'error': str(e)}, 500

    def post(self):
        try:
            data = request.get_json()
            title = data.get('title')
            artist = data.get('artist')
            duration = data.get('duration')

            new_song = Song(title=title, artist=artist, duration=duration)
            db.session.add(new_song)
            db.session.commit()

            return jsonify({'message': 'Song added successfully'})
        except Exception as e:
            return {'error': str(e)}, 500

api.add_resource(SongAPI, '/api/songs')
# Remove duplicate user loader function
# @login_manager.user_loader
# def load_user(user_id):
#     return User.query.get(int(user_id))


@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    if current_user.is_creator:
        return render_template('dashboard.html', username=current_user.username)
    else:
        return render_template('user_dashboard.html', username=current_user.username)

from werkzeug.utils import secure_filename
import os


from flask import send_from_directory


@app.route('/mp3/<filename>')
def serve_mp3(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/songs')
def songs():
    if current_user.is_admin:
        songs = Song.query.all()
        return render_template('songs.html', songs=songs)
    elif current_user.is_creator:
        songs = Song.query.filter_by(artist=current_user.username).all()
        return render_template('songs.html', songs=songs)
    else:
        songs = Song.query.all()
        return render_template('user_songs.html', songs=songs)
@app.route('/albums')
def albums():
    if current_user.is_admin:
        albums = Album.query.all()
        return render_template('albums.html', albums=albums)
    elif current_user.is_creator:
        albums = Album.query.filter_by(artist=current_user.username).all()
        return render_template('albums.html', albums=albums)
    else:
        albums = Album.query.all()
        return render_template('user_albums.html', albums=albums)

# Route for adding a new album
@app.route('/add_album', methods=['GET', 'POST'])
def add_album():
    if request.method == 'POST':
        title = request.form['title']
        artist = request.form['artist']
        release_year = request.form['release_year']

        # Check if an album art file was uploaded
        if 'album_art' in request.files:
            album_art_file = request.files['album_art']

            # Check if the file is not empty
            if album_art_file.filename != '':
                # Generate a secure filename and save the file to the server
                filename = secure_filename(album_art_file.filename)
                album_art_file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            else:
                filename = None
        else:
            filename = None

        # Create a new album with the uploaded album art filename
        new_album = Album(title=title, artist=artist, release_year=release_year, album_art=filename)
        db.session.add(new_album)
        db.session.commit()

        flash('Album added successfully.', 'success')
        return redirect(url_for('albums'))

    return render_template('add_album.html')
@app.route('/edit_album/<int:album_id>', methods=['GET', 'POST'])
def edit_album(album_id):
    album = Album.query.get_or_404(album_id)

    if request.method == 'POST':
        # Update the album details
        album.title = request.form['title']
        album.artist = request.form['artist']
        album.release_year = request.form['release_year']

        db.session.commit()

        flash('Album updated successfully.', 'success')
        return redirect(url_for('albums'))

    return render_template('edit_album.html', album=album)

# Route for deleting an album
@app.route('/delete_album/<int:album_id>', methods=['POST'])
def delete_album(album_id):
    album = Album.query.get_or_404(album_id)
    db.session.delete(album)
    db.session.commit()

    flash('Album deleted successfully.', 'success')
    return redirect(url_for('albums'))

@app.route('/playlists')
def playlists():
    playlists = Playlist.query.all()
    return render_template('playlists.html', playlists=playlists)

# Import necessary modules
from flask import request

# ... (existing code)

# Create a new playlist and add existing songs
@app.route('/create_playlist', methods=['GET', 'POST'])
def create_playlist():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']

        # Create a new playlist and save it to the database
        new_playlist = Playlist(title=title, description=description)
        db.session.add(new_playlist)
        db.session.commit()

        flash('Playlist created successfully.', 'success')
        return redirect(url_for('playlists'))

    return render_template('create_playlist.html')


# Add existing songs to a playlist
@app.route('/add_to_playlist/<int:playlist_id>', methods=['GET', 'POST'])
def add_to_playlist(playlist_id):
    playlist = Playlist.query.get_or_404(playlist_id)

    if request.method == 'POST':
        song_ids = request.form.getlist('song_ids')

        # Fetch the selected songs from the database
        songs = Song.query.filter(Song.id.in_(song_ids)).all()

        # Add the selected songs to the playlist
        playlist.songs.extend(songs)
        db.session.commit()

        flash('Songs added to the playlist successfully.', 'success')
        return redirect(url_for('playlists'))

    # Provide the list of available songs to choose from
    songs = Song.query.all()
    return render_template('add_to_playlist.html', playlist=playlist, songs=songs)

from flask import render_template

@app.route('/playlist_songs/<int:playlist_id>')
def playlist_songs(playlist_id):
    playlist = Playlist.query.get_or_404(playlist_id)
    return render_template('playlist_songs.html', playlist=playlist)


# Remove songs from a playlist
@app.route('/remove_from_playlist/<int:playlist_id>', methods=['GET', 'POST'])
def remove_from_playlist(playlist_id):
    playlist = Playlist.query.get_or_404(playlist_id)

    if request.method == 'POST':
        song_ids = request.form.getlist('song_ids')

        # Fetch the selected songs from the playlist
        songs = Song.query.filter(Song.id.in_(song_ids)).all()

        # Remove the selected songs from the playlist
        for song in songs:
            playlist.songs.remove(song)

        db.session.commit()

        flash('Songs removed from the playlist successfully.', 'success')
        return redirect(url_for('playlists'))

    # Provide the list of songs in the playlist to choose from
    return render_template('remove_from_playlist.html', playlist=playlist)

# ... (existing code)
@app.route('/edit_playlist/<int:playlist_id>', methods=['GET', 'POST'])
def edit_playlist(playlist_id):
    playlist = Playlist.query.get_or_404(playlist_id)

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']

        # Update the playlist details
        playlist.title = title
        playlist.description = description

        db.session.commit()

        flash('Playlist updated successfully.', 'success')
        return redirect(url_for('playlists'))

    return render_template('edit_playlist.html', playlist=playlist)

# Add this route to your app.py file
from flask import redirect, url_for

@app.route('/delete_playlist/<int:playlist_id>', methods=['POST'])
def delete_playlist(playlist_id):
    # Get the playlist from the database
    playlist = Playlist.query.get_or_404(playlist_id)

    # Delete the playlist
    db.session.delete(playlist)
    db.session.commit()

    flash('Playlist deleted successfully.', 'success')
    return redirect(url_for('playlists'))


@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        search_query = request.form.get('search_query')
        # Perform search logic based on the search_query
        # You can search for songs, albums, or playlists that match the query
        songs = Song.query.filter(
            db.or_(
                Song.title.ilike(f'%{search_query}%'),
                Song.artist.ilike(f'%{search_query}%')
            )
        ).all()
        albums = Album.query.filter(
            db.or_(
                Album.title.ilike(f'%{search_query}%'),
                Album.artist.ilike(f'%{search_query}%')
            )
        ).all()
        playlists = Playlist.query.filter(
            Playlist.title.ilike(f'%{search_query}%')
        ).all()
        return render_template('search.html', songs=songs, albums=albums, playlists=playlists)
    return render_template('search.html')

# Add songs to an album
@app.route('/add_songs_to_album/<int:album_id>', methods=['GET', 'POST'])
def add_songs_to_album(album_id):
    album = Album.query.get_or_404(album_id)

    if request.method == 'POST':
        song_ids = request.form.getlist('song_ids')

        # Fetch the selected songs from the database
        songs = Song.query.filter(Song.id.in_(song_ids)).all()

        # Add the selected songs to the album
        album.songs.extend(songs)
        db.session.commit()

        flash('Songs added to the album successfully.', 'success')
        return redirect(url_for('albums'))

    # Provide the list of available songs to choose from
    songs = Song.query.all()
    return render_template('add_songs_to_album.html', album=album, songs=songs)

@app.route('/update_rating/<int:song_id>', methods=['POST'])
def update_rating(song_id):
    song = Song.query.get_or_404(song_id)

    if request.method == 'POST':
        rating = int(request.form['rating'])

        # Update the song's rating
        song.rating = rating
        db.session.commit()

        flash('Rating updated successfully.', 'success')
        return redirect(url_for('songs'))

    # Redirect to the songs page if not a POST request
    return redirect(url_for('songs'))

from flask import jsonify

# Blacklist a user and remove their songs
@app.route('/blacklist_user/<int:user_id>', methods=['POST'])
def blacklist_user(user_id):
    # Get the user from the database
    user = User.query.get_or_404(user_id)

    # Check if the user is an artist (creator)
    if user.is_creator:
        # Get all the songs uploaded by the user
        user_songs = Song.query.filter_by(artist=user.username).all()

        # Delete the user's songs from the database
        for song in user_songs:
            db.session.delete(song)

    # Delete the user
    db.session.delete(user)
    db.session.commit()

    flash('User blacklisted successfully, and their songs have been removed.', 'success')
    return redirect(url_for('admin_dashboard'))



@app.route('/logout')
@login_required
def logout():
    logout_user()  # Log out the user
    return redirect(url_for('home'))



'''@app.route('/add_song', methods=['GET', 'POST'])
def add_song():
    if request.method == 'POST':
        title = request.form['title']
        artist = request.form['artist']
        duration = request.form['duration']

        # Create a new song and save it to the database
        new_song = Song(title=title, artist=artist, duration=duration)
        db.session.add(new_song)
        db.session.commit()

        flash('Song added successfully.', 'success')
        return redirect(url_for('songs'))

    return render_template('add_song.html')'''




if __name__ == '__main__':
    with app.app_context():
        db.create_all()

    app.run(debug=True)
